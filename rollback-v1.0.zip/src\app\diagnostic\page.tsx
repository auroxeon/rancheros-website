'use client'

export default function DiagnosticPage() {
  return (
    <div style={{
      fontSize: '72px',
      fontWeight: 'bold',
      color: 'green',
      backgroundColor: 'yellow',
      padding: '50px',
      textAlign: 'center',
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'Arial, sans-serif'
    }}>
      DIAGNOSTIC WORKS
    </div>
  )
}

