Hero Component - Luxury Gardens Style

Place Hero.tsx and Hero.module.css in the same folder (e.g., /components/Hero)
Add /public/images/hero-garden-wide.jpg for the background.
Import and use <Hero /> in your homepage.
