export default function MinimalPage() {
  return <div style={{padding:'50px',fontSize:'48px',color:'red'}}>MINIMAL TEST</div>
}

