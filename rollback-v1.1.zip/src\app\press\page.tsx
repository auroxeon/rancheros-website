import Hero from '@/components/Hero'
import PrimarySections from '@/components/PrimarySections'

export default function PressPage() {
  return (
    <>
      <Hero />
      <PrimarySections />
    </>
  )
}


