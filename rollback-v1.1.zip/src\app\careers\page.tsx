import Hero from '@/components/Hero'
import PrimarySections from '@/components/PrimarySections'

export default function CareersPage() {
  return (
    <>
      <Hero />
      <PrimarySections />
    </>
  )
}


