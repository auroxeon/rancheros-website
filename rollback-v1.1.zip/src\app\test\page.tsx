export default function TestPage() {
  return (
    <div style={{ padding: '50px', fontSize: '24px' }}>
      <h1>Test Page</h1>
      <p>If you can see this, Next.js is working!</p>
    </div>
  )
}



