'use client'

import { useState } from 'react'
import Link from 'next/link'
import LoginModal from './LoginModal'
import Navigation from './Navigation'

export default function Header() {
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false)

  // Navigation items structure
  const navItems = [
    { label: "Home", href: "/" },
    {
      label: "Grills Design",
      href: "/garden-design"
    },
    {
      label: "Outdoor Living Designers",
      children: [
        { label: "Landscape Designers", href: "/landscape-designers" },
        { label: "Architects", href: "/architects" },
        { label: "Garden Designers", href: "/garden-designers" },
        { label: "Homeowners", href: "/homeowners" },
        { label: "Developers", href: "/developers" },
      ],
    },
    {
      label: "Our Products",
      children: [
        { label: "Single Grills", href: "/single-grills" },
        { label: "Double Grills", href: "/double-grills" },
        { label: "Accessories", href: "/accessories" },
        { label: "Bespoke", href: "/bespoke" },
        { label: "Services", href: "/services" },
      ],
    },
    {
      label: "About Us",
      children: [
        { label: "About", href: "/about" },
        { label: "News", href: "/news" },
        { label: "Careers", href: "/careers" },
        { label: "Press", href: "/press" },
      ],
    },
    { label: "Circulo del Fuego Club", href: "/blog" },
    { label: "Contact Us", href: "/contact" },
  ]

  return (
    <>
      <header className="navbar">
        <div className="navbar__container">
          {/* Logo on far left */}
          <div className="navbar__logo">
            <Link href="/">
              <img 
                src="/logo-icon.png" 
                alt="Rancheros Grills"
                width={117}
                height={81}
              />
            </Link>
          </div>

          {/* Navigation in center */}
          <Navigation items={navItems} />

          {/* Login button on far right */}
          <button 
            className="navbar__login-btn"
            onClick={(e) => {
              e.preventDefault()
              e.stopPropagation()
              console.log('Login button clicked')
              setIsLoginModalOpen(true)
            }}
            aria-label="Login"
            type="button"
          >
            Login
          </button>
        </div>
      </header>

      {/* Login/Register Modal */}
      <LoginModal 
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
      />
    </>
  )
}
